#ifndef PRODUTO_H
#define PRODUTO_H

struct Produto {
    int id;
    char nome[50];
    int quantidade;
    struct Produto *prox;
};

typedef struct Produto Produto;

#endif
