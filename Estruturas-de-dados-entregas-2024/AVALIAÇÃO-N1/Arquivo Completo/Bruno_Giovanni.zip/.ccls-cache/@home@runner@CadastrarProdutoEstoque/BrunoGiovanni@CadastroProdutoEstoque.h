#ifndef CADASTROPRODUTOESTOQUE_H
#define CADASTROPRODUTOESTOQUE_H

#include "Produto.h"

void cadastrarProduto(Produto **estoque, int id, char nome[], int quantidade);

#endif
