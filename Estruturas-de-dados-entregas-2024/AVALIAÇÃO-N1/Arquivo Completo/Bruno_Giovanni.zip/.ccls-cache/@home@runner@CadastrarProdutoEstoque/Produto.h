typedef struct {
  int id;
  char nome[100];
  int quantidade;
  struct Produto *prox;
} Produto;
