#ifndef BUSCAESTOQUE_H
#define BUSCAESTOQUE_H

#include "Produto.h"

Produto* buscarProduto(Produto *estoque, int id);

#endif
