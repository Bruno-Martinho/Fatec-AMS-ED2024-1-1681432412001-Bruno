#ifndef OPERACOESPRODUTO_H
#define OPERACOESPRODUTO_H

#include "Produto.h"

void liberarEstoque(Produto *estoque);

#endif /* OPERACOESPRODUTO_H */
